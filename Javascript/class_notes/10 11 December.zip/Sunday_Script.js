// Conditions

// If Else
// switch case
// Ternary Op / ternary Conditions

// Rating mini App

// let rating = 7;

// if (rating == 5) {
//     console.log('5 Stars');
// } else if (rating == 4) {
//     console.log('4 Stars');
// } else if (rating == 3) {
//     console.log('3 Stars');
// } else {
//     console.log('i am else');
// }

//  Switch Case

// let user = 'Admin';

// switch (user) {
//     case 'Admin':
//         console.log('Redirect Him/Her to the Admin Page');
//         break;
//     case 'Mentor':
//         console.log('Redirect Him/Her to the Mentor Dashboard');
//         break;
//     default:
//         console.log('I am Simple User');
// }

// ternary Opeartor / Ternary Condition

// Condition?True:Flase

// let userlogin = true;

// userlogin ? console.log('logout') : console.log('login');
// Condition ? True : False;

// Array

// let name = [
//     'Anirudh',
//     'Anurag',
//     'Shubham',
//     'Bishal',
//     'Pooja',
//     'santosh',
//     'Prajwal',
//     'Monika',
//     'Pritam',
// ];

// console.log(name);
// console.log(name[6]);

// Object

// let backaccount = {
//     firstName: 'Nabeela',
//     lastName: 'laStname',
//     mobileno: 9978899788,
//     balance: 99999999900099,
// };

// console.log(backaccount);
// console.log(backaccount.balance);

// Date and Math

// const now = new Date();
// console.log(now.toString());

// console.log(now.getFullYear());
// console.log(now.getMonth());
// console.log(now.getDay());

// console.log(now.getTime());

// console.log(now.getHours());
// console.log(now.getMinutes());
// console.log(now.getSeconds());

// Math

// const PI = Math;
// console.log(PI);

// console.log(Math.round(PI));
// console.log(Math.round(9.4));
// console.log(Math.floor(9.5));
// console.log(Math.ceil(9.5));

// min and max

// console.log(Math.min(10, 1, 2, 3, 5));
// console.log(Math.max(10, 1, 2, 3, 5));

// Random

// console.log(Math.round(Math.random() * 51)); // 0 - 0.99999999999 (0-1)

//

// console.log(Math.pow(3, 3));

// console.log(Math.log(2));

// console.log(Math.sin(90));

// Loops
// do while, while, for

// let i = 6;
// do {
//     console.log('Value of i is :', i);
//     i++;
// } while (i <= 5);

// let j = 6;

// while (j <= 5) {
//     console.log('Value of J is ', j);
//     j++;
// }

// for

for (let i = 0; i <= 10; i++) {
    console.log(`${i} * ${i} = ${i * i}`);
}
