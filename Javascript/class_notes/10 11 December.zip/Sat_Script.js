// 7;
// 2.5;
// // Number values

// ('anurag');
// ('anurag');
// // String Values

// true;
// false;
// // Boolean values

// null;
// undefined;

// // Empty values

// // Prmitive values / PDT => One Single Value

// // Array and Object

// [1, 2, 'Anurag', true, 'anurag',"Shivam","Swapnil"];
//  0, 1,  2          3       4, 5, 6 => Index

// {
//     fname:anurag,
//     lname:tiwari
// }

// // Non- primitive Data Types => Will More then one value

// Varibales => Place holder for value

// let x = 25;

// const z = '59890000000000'; // constant
// const balance = 999999999;

// let firstname = 'Anurag';
// let lastname = 'Tiwari';
// const mobileno = 9978899788;

// console.log('MY First name  is ' + firstname);
// console.log('My Last Name is', lastname);
// console.log(mobileno, firstname, lastname);

// Tempate Literal

// console.log(`My Current First Name is ${firstname} ${lastname} ${mobileno}`);
// History
// Basic Pillar of an programming Language
// Values
// Data Types
// Difference between Primitive and non primitive Datatypes
// Console.log => How to print something on terminal
// Decalring Variable
// Tempalte Literal

// Operator

// Assignment Operator

// let x = 11;
// let y = 10;

// Arthimatic Operator
// +, -, *. /, (% => Remainder)
// let z = x + y;
// console.log(z);

// console.log(x + y);
// console.log(x - y);
// console.log(x * y);
// console.log(x / y);
// console.log(x % y);

// Comparison Op

// let abc = 10;
// let xyz = '10';

// console.log(abc > xyz);
// console.log(abc <= xyz);
// console.log(abc >= xyz);

// == or ===

// console.log(abc === xyz);

// let y;
// // y = 10;
// console.log(y);

// const accno = 5958900000;

// Conditions

let Standard = 7;

if (Standard == 1) {
    console.log('Room One');
} else if (Standard == 2) {
    console.log('Rome Two');
} else if (Standard == 3) {
    console.log('Room Number 3');
} else {
    console.log('You are Principal');
}
